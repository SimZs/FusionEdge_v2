var hostname = window.location.hostname;
var modesd = false;
const query = window.location.search;
const params = new URLSearchParams(query);
const yoTitle = 'FusionEdge';
let audiopreview=null;
if(params.size>0){
  if(params.has('host')) hostname=params.get('host');
}
var websocket;
var wsQueue = [];
var wserrcnt = 0;
var wstimeout;
var loaded = false;
var wsOpenedOnce = false;
var currentItem = 0;
var independentEncodersAvailable = true;

function wsSend(message) {
  if (!message) return;
  if (websocket && websocket.readyState === WebSocket.OPEN) {
    websocket.send(message);
    return;
  }
  wsQueue.push(message);
}

function flushWsQueue() {
  if (!websocket || websocket.readyState !== WebSocket.OPEN) return;
  while (wsQueue.length > 0) {
    websocket.send(wsQueue.shift());
  }
}

window.addEventListener('load', onLoad);

function loadCSS(href){ const link = document.createElement("link"); link.rel = "stylesheet"; link.href = href; document.head.appendChild(link); }
function loadJS(src, callback){ const script = document.createElement("script"); script.src = src; script.type = "text/javascript"; script.async = true; script.onload = callback; document.head.appendChild(script); }

function initWebSocket() {
  clearTimeout(wstimeout);
  console.log('Trying to open a WebSocket connection...');
  websocket = new WebSocket(`ws://${hostname}/ws`);
  websocket.onopen    = onOpen;
  websocket.onclose   = onClose;
  websocket.onmessage = onMessage;
}

// Render initial UI without waiting for WebSocket handshake.
function onLoad(event) {
  if (!loaded) {
    const initialMode = (typeof playMode === 'undefined' || !playMode) ? 'ap' : playMode;
    continueLoading(initialMode); // playMode comes from variables.js
    loaded = true;
  }
  // Fail-safe: never leave the UI blocked by spinner forever.
  setTimeout(() => {
    const p = getId('progress');
    const c = getId('content');
    if (p && !p.classList.contains('hidden')) {
      hideSpinner();
      if (c && (!c.innerHTML || c.innerHTML.trim() === '')) {
        c.innerHTML = '<div style="padding:20px;text-align:center;">Page load timeout. Open <a href="/webboard">/webboard</a>.</div>';
      }
    }
  }, 8000);
  initWebSocket();
}

function onOpen(event) {
  const reconnect = wsOpenedOnce;
  wsOpenedOnce = true;
  console.log('Connection opened');
  if (!loaded) {
    const initialMode = (typeof playMode === 'undefined' || !playMode) ? 'ap' : playMode;
    continueLoading(initialMode); //playMode in variables.js
    loaded = true;
  }
  wserrcnt=0;
  flushWsQueue();
  if(reconnect && (getId('btpairedrows') || getId('btsourcerows'))){
    // A scan result or paired-list update may have been in flight when the
    // socket dropped. Rebuild both caches from the firmware after reconnect.
    wsSend('getbtinput=1');
    wsSend('getbtoutput=1');
  }
}
function onClose(event) {
  wserrcnt++;
  wstimeout=setTimeout(initWebSocket, wserrcnt<10?2000:120000);
}
function secondToTime(seconds){
  if(seconds>=3600){
    return new Date(seconds * 1000).toISOString().substring(11, 19);
  }else{
    return new Date(seconds * 1000).toISOString().substring(14, 19);
  }
}
function showById(show,hide){
  show.forEach(item=>{ getId(item).classList.remove('hidden'); });
  hide.forEach(item=>{ getId(item).classList.add('hidden'); });
}
let btInputState = {role:'unknown', a2dp:0, pending:true, controlPending:true, discoverable:-1, address:'', name:'', codec:'', sampleRate:0, battery:-1, batteryAddress:''};
let btOutputState = {role:'unknown', a2dp:0, scanning:false, scanPreparing:false, pending:false, playing:false, routePending:false, ready:false, btEnabled:-1, address:'', name:'', codec:'', sampleRate:0, battery:-1, batteryAddress:''};
const btPairedDevices = new Map();
let btPairedRefreshActive = false;
let btDeviceDialogAddress = '';

function btAddress(value){ return String(value||'').toUpperCase(); }
function btIsConnected(state){ return !!state && state.a2dp>=3 && state.a2dp<=5; }
function btFormatRate(rate){
  rate=Number(rate)||0;
  return rate ? (rate%1000===0 ? (rate/1000)+' kHz' : rate+' Hz') : '';
}
function btFormatBattery(level){
  level=Number(level);
  return Number.isFinite(level) && level>=0 && level<=5 ? (level*20)+'%' : '—';
}
function btBatteryLevelForState(state){
  if(!btIsConnected(state)) return -1;
  const connectedAddress=btAddress(state.address);
  const batteryAddress=btAddress(state.batteryAddress);
  const level=Number(state.battery);
  return connectedAddress && batteryAddress===connectedAddress &&
         Number.isFinite(level) && level>=0 && level<=5 ? level : -1;
}
function btCurrentRole(){
  if(btOutputState.role==='source/output') return 'source/output';
  if(btInputState.role==='sink/input') return 'sink/input';
  return btOutputState.role!=='unknown' ? btOutputState.role : btInputState.role;
}
function btSourceUiReady(){
  return btOutputState.role==='source/output' && btOutputState.ready===true;
}
function updateBtRoleStatus(){
  const role=btCurrentRole();
  const source=role==='source/output';
  const state=source?btOutputState:btInputState;
  const connected=btIsConnected(state);
  const connection=getId('btroleconnection');
  const details=getId('btrolecodec');
  if(connection){
    let text='';
    if(source && !btSourceUiReady()){
      text=state.routePending
        ? 'Bluetooth output setup: applying output mode...'
        : 'Bluetooth output setup: loading paired devices...';
    }else{
      text='Role: '+role+'. ';
      if(state.a2dp===2 || state.pending) text+='Connecting...';
      else if(connected){
        text+=(source && state.playing)?'Playing':'Connected';
        if(source && !state.playing) text='Role: '+role+'. Paused';
        const peer=state.name||state.address;
        if(peer) text+=' — '+peer;
      }else if(source && Number((getId('btsourcelocal')||{}).value||1)===2){
        text+='Local only; Bluetooth radio disabled.';
      }else{
        text+=source?'No Bluetooth speaker connected.':'No phone or computer connected.';
      }
    }
    connection.textContent=text;
  }
  if(details){
    const parts=[];
    if(connected && state.codec) parts.push('Codec: '+state.codec);
    const rate=connected?btFormatRate(state.sampleRate):'';
    if(rate) parts.push(rate);
    const battery=btBatteryLevelForState(state);
    if(battery>=0) parts.push('Battery: '+btFormatBattery(battery));
    details.textContent=parts.length
      ? parts.join(' · ')
      : 'Codec, sample rate and battery will appear when reported by the connected device.';
  }
}
function handleBtInputState(state){
  btInputState=Object.assign(btInputState,state||{});
  const alias=getId('btalias');
  const status=getId('btinputstatus');
  const pair=getId('btpair');
  const pairStatus=getId('btpairstatus');
  if(alias && document.activeElement!==alias) alias.value=btInputState.alias||btInputState.current||'';
  if(status){
    status.style.color=(!btInputState.synchronized && !btInputState.pending)?'#e36b6b':'';
    if(btInputState.message && /alias|module name/i.test(btInputState.message)) status.textContent=btInputState.message;
    else if(btInputState.pending) status.textContent='Waiting for Bluetooth alias synchronization...';
    else if(btInputState.synchronized) status.textContent='Active module name: '+(btInputState.current||btInputState.alias||'');
    else status.textContent='Bluetooth module name is not available yet.';
  }
  const discoverable=Number(btInputState.discoverable);
  if(pair) pair.classList.toggle('checked',discoverable===1);
  if(pairStatus){
    const message=btInputState.message||'';
    if(/discover|hidden from new devices|module is busy|only in Bluetooth input mode/i.test(message)){
      pairStatus.textContent=message;
    }else if(btInputState.role!=='sink/input'){
      pairStatus.textContent='Available in Bluetooth input mode.';
    }else if(btInputState.controlPending){
      pairStatus.textContent='Reading Bluetooth discoverability...';
    }else if(discoverable===1){
      pairStatus.textContent='New phones and computers can discover and pair with this device.';
    }else if(discoverable===0){
      pairStatus.textContent='Hidden from new devices; already paired devices can still connect.';
    }else{
      pairStatus.textContent='Bluetooth discoverability is not available yet.';
    }
  }
  updateBtRoleStatus();
  updateBtInputControls();
  updateBtPairedRows();
}
function setBtActionEnabled(id, enabled){
  const el=getId(id);
  if(!el) return;
  setBtElementEnabled(el,enabled);
}
function setBtElementEnabled(el,enabled){
  if(!el) return;
  el.style.pointerEvents=enabled?'':'none';
  el.style.opacity=enabled?'':'0.45';
  el.setAttribute('aria-disabled',enabled?'false':'true');
}
function updateBtInputControls(){
  const inputReady=btInputState.role==='sink/input';
  const pairedListReady=inputReady || btSourceUiReady();
  const bluetoothBusy=btInputState.controlPending || btOutputState.pending || btOutputState.routePending || btOutputState.scanning || btOutputState.scanPreparing;
  const alias=getId('btalias');
  if(alias) alias.disabled=!inputReady || btInputState.pending;
  setBtActionEnabled('applybtaliasbutton',inputReady && !btInputState.pending && !bluetoothBusy);
  setBtActionEnabled('btpair',inputReady && !btInputState.pending && !bluetoothBusy);
  setBtActionEnabled('btinputrefreshbutton',pairedListReady && !bluetoothBusy);
}
function btPairedDeviceType(profile){
  const bitmap=Number(profile)||0;
  const input=(bitmap&32)!==0;
  const output=(bitmap&64)!==0;
  if(input&&output) return 'Input + output';
  if(input) return 'Input';
  if(output) return 'Output';
  return 'Unknown';
}
function handleBtPairedEvent(item){
  if(!item) return;
  const status=getId('btpairedstatus');
  if(item.event==='clear'){
    btPairedRefreshActive=true;
    btPairedDevices.forEach(device=>{ device.refreshSeen=false; });
    updateBtPairedRows();
  }
  if(item.event==='device' && item.address){
    const address=btAddress(item.address);
    const previous=btPairedDevices.get(address)||{};
    btPairedDevices.set(address,Object.assign(previous,item,{address:address,refreshSeen:true}));
    const nearby=document.querySelector('#btsourcerows .bt-source-row[data-address="'+address+'"]');
    if(nearby) nearby.remove();
    updateBtPairedRows();
  }
  if(item.event==='done' || item.event==='idle'){
    if(btPairedRefreshActive){
      btPairedDevices.forEach((device,address)=>{
        if(!device.refreshSeen) btPairedDevices.delete(address);
        else delete device.refreshSeen;
      });
    }
    btPairedRefreshActive=false;
    updateBtPairedRows();
  }
  if(status){
    status.style.color=item.event==='error'?'#e36b6b':'';
    if(item.message) status.textContent=item.message;
    else if(item.event==='done') status.textContent=(item.count||0)+' paired device(s).';
    else if(item.event==='idle') status.textContent='No paired devices.';
    else if(item.event==='refreshing') status.textContent='Refreshing paired-device list...';
    else if(item.event==='forgetting') status.textContent='Removing paired device...';
  }
  updateBtInputControls();
}
function createBtAction(command,address,label,text,className){
  const action=document.createElement('div');
  action.className='fb local '+className;
  action.dataset.command=command;
  action.dataset.address=address;
  action.dataset.label=label;
  action.textContent=text;
  action.setAttribute('role','button');
  action.setAttribute('tabindex','0');
  return action;
}
function btIconSvg(kind){
  if(kind==='settings') return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 15.25A3.25 3.25 0 1 0 12 8.75a3.25 3.25 0 0 0 0 6.5Z"/><path d="M19.4 13.5a7.9 7.9 0 0 0 0-3l2-1.55-2-3.45-2.45 1A8.1 8.1 0 0 0 14.35 5L14 2.4h-4L9.65 5a8.1 8.1 0 0 0-2.6 1.5l-2.45-1-2 3.45 2 1.55a7.9 7.9 0 0 0 0 3l-2 1.55 2 3.45 2.45-1a8.1 8.1 0 0 0 2.6 1.5l.35 2.6h4l.35-2.6a8.1 8.1 0 0 0 2.6-1.5l2.45 1 2-3.45-2-1.55Z"/></svg>';
  if(kind==='disconnect') return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8.2 16.2 6.4 18a3.4 3.4 0 0 1-4.8-4.8l3.1-3.1a3.4 3.4 0 0 1 4.1-.55M15.8 7.8 17.6 6a3.4 3.4 0 0 1 4.8 4.8l-3.1 3.1a3.4 3.4 0 0 1-4.1.55M8.1 7.2 6.7 5.8M6 9.4H3.8M15.9 16.8l1.4 1.4M18 14.6h2.2"/></svg>';
  return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9.4 14.6l5.2-5.2M7.7 17.8l-1.3 1.3a3.5 3.5 0 0 1-5-5l3.3-3.3a3.5 3.5 0 0 1 5 0M16.3 6.2l1.3-1.3a3.5 3.5 0 0 1 5 5l-3.3 3.3a3.5 3.5 0 0 1-5 0"/></svg>';
}
function createBtIconAction(command,address,label,kind,title,className){
  const action=document.createElement('div');
  action.className='bt-icon-action local '+className;
  action.dataset.command=command;
  action.dataset.address=address;
  action.dataset.label=label;
  action.innerHTML=btIconSvg(kind);
  action.setAttribute('role','button');
  action.setAttribute('tabindex','0');
  action.setAttribute('aria-label',title);
  action.title=title;
  return action;
}
function closeBtDeviceDialog(){
  const overlay=getId('btdeviceoverlay');
  if(overlay) overlay.classList.add('hidden');
  document.body.classList.remove('bt-device-dialog-open');
  btDeviceDialogAddress='';
}
function renderBtDeviceDialog(){
  if(!btDeviceDialogAddress) return;
  const item=btPairedDevices.get(btDeviceDialogAddress);
  const overlay=getId('btdeviceoverlay');
  const actions=getId('btdeviceactions');
  if(!item || !overlay || !actions){
    closeBtDeviceDialog();
    return;
  }
  const address=btAddress(item.address);
  const name=item.name||'Unknown device';
  const profile=Number(item.profile)||0;
  const role=btCurrentRole();
  const sourceReady=role==='source/output';
  const outputMode=Number((getId('btsourcelocal')||{}).value||1);
  const localOnly=outputMode===2;
  const busy=btInputState.controlPending || btOutputState.pending || btOutputState.routePending || btOutputState.scanning || btOutputState.scanPreparing;
  const sinkAddress=role==='sink/input' && btIsConnected(btInputState)
    ? btAddress(btInputState.address) : '';
  const sourceAddress=role==='source/output' && btIsConnected(btOutputState)
    ? btAddress(btOutputState.address) : '';
  const isConnected=address && (address===sinkAddress || address===sourceAddress);
  const outputCapable=(profile&64)!==0 || profile===0;
  const title=getId('btdevicetitle');
  const type=getId('btdevicetype');
  const mac=getId('btdevicemac');
  if(title) title.textContent=name+(isConnected?' · Connected':'');
  if(type) type.textContent=btPairedDeviceType(profile);
  if(mac) mac.textContent=address||'—';
  actions.replaceChildren();
  if(sourceReady && isConnected){
    const disconnect=createBtAction('btdisconnect',address,name,'Disconnect','bt-device-primary');
    setBtElementEnabled(disconnect,!localOnly && !busy);
    actions.appendChild(disconnect);
  }else if(sourceReady && outputCapable){
    const connect=createBtAction('btconnect',address,name,'Connect','bt-device-primary');
    setBtElementEnabled(connect,!localOnly && !busy && !btIsConnected(btOutputState));
    actions.appendChild(connect);
  }
  const forget=createBtAction('btforget',address,name,'Forget','bt-device-forget');
  setBtElementEnabled(forget,!busy && !isConnected);
  actions.appendChild(forget);
}
function openBtDeviceDialog(address){
  address=btAddress(address);
  if(!address || !btPairedDevices.has(address)) return;
  btDeviceDialogAddress=address;
  const overlay=getId('btdeviceoverlay');
  if(!overlay) return;
  if(overlay.parentElement!==document.body) document.body.appendChild(overlay);
  renderBtDeviceDialog();
  overlay.classList.remove('hidden');
  document.body.classList.add('bt-device-dialog-open');
}
function updateBtPairedRows(){
  const rows=getId('btpairedrows');
  if(!rows) return;
  rows.replaceChildren();
  const visibleDevices=Array.from(btPairedDevices.values()).filter(item=>!btPairedRefreshActive || item.refreshSeen);
  if(visibleDevices.length===0){
    const empty=document.createElement('div');
    empty.className='bt-paired-empty';
    empty.textContent='No paired devices';
    rows.appendChild(empty);
    renderBtDeviceDialog();
    return;
  }
  const role=btCurrentRole();
  const sourceReady=role==='source/output';
  const outputMode=Number((getId('btsourcelocal')||{}).value||1);
  const localOnly=outputMode===2;
  const busy=btInputState.controlPending || btOutputState.pending || btOutputState.routePending || btOutputState.scanning || btOutputState.scanPreparing;
  const sinkAddress=role==='sink/input' && btIsConnected(btInputState)
    ? btAddress(btInputState.address) : '';
  const sourceAddress=role==='source/output' && btIsConnected(btOutputState)
    ? btAddress(btOutputState.address) : '';
  visibleDevices.forEach(item=>{
    const address=btAddress(item.address);
    const name=item.name||'Unknown device';
    const profile=Number(item.profile)||0;
    const isConnected=address && (address===sinkAddress || address===sourceAddress);
    const row=document.createElement('div');
    row.className='bt-paired-row'+(isConnected?' connected':'');
    row.setAttribute('role','row');
    row.dataset.address=address;
    row.dataset.profile=String(profile);

    const device=document.createElement('div');
    device.className='bt-paired-device';
    device.setAttribute('role','cell');
    const deviceName=document.createElement('span');
    deviceName.className='bt-paired-name';
    deviceName.textContent=name;
    const connected=document.createElement('span');
    connected.className='bt-paired-connected';
    connected.textContent='Connected';
    const type=document.createElement('div');
    type.className='bt-paired-type';
    type.textContent=btPairedDeviceType(profile);
    device.append(deviceName,type,connected);
    const rssi=document.createElement('div');
    rssi.className='bt-paired-rssi';
    rssi.setAttribute('role','cell');
    rssi.textContent=Number.isFinite(Number(item.rssi))?Number(item.rssi)+' dBm':'—';
    const battery=document.createElement('div');
    battery.className='bt-paired-battery';
    battery.setAttribute('role','cell');
    const activeState=address===sourceAddress?btOutputState:(address===sinkAddress?btInputState:null);
    const batteryLevel=activeState?btBatteryLevelForState(activeState):-1;
    battery.textContent=batteryLevel>=0?btFormatBattery(batteryLevel):'—';
    if(batteryLevel>=0) battery.title='Remote HFP battery level: '+batteryLevel+'/5';
    const quickAction=document.createElement('div');
    quickAction.className='bt-paired-quick-action';
    quickAction.setAttribute('role','cell');
    const outputCapable=(profile&64)!==0 || profile===0;
    if(sourceReady && isConnected){
      const disconnect=createBtIconAction('btdisconnect',address,name,'disconnect','Disconnect '+name,'bt-paired-connect');
      setBtElementEnabled(disconnect,!localOnly && !busy);
      quickAction.appendChild(disconnect);
    }else if(sourceReady && outputCapable){
      const connect=createBtIconAction('btconnect',address,name,'connect','Connect '+name,'bt-paired-connect');
      setBtElementEnabled(connect,!localOnly && !busy && !btIsConnected(btOutputState));
      quickAction.appendChild(connect);
    }else{
      const unavailable=document.createElement('span');
      unavailable.className='bt-paired-action-unavailable';
      unavailable.textContent='—';
      quickAction.appendChild(unavailable);
    }
    const settings=document.createElement('div');
    settings.className='bt-paired-settings';
    settings.setAttribute('role','cell');
    settings.appendChild(createBtIconAction('btdeviceinfo',address,name,'settings','Device settings for '+name,'bt-paired-settings-button'));
    row.append(device,rssi,battery,quickAction,settings);
    row.title=profile?'Reported profile bitmap: '+profile:'No profile bitmap reported';
    rows.appendChild(row);
  });
  renderBtDeviceDialog();
}
function updateBtOutputControls(){
  const sourceReady=btSourceUiReady();
  const outputMode=Number((getId('btsourcelocal')||{}).value||1);
  const localOnly=outputMode===2;
  const routeBusy=!!btOutputState.routePending;
  const connected=btOutputState.a2dp>=3 && btOutputState.a2dp<=5;
  const connecting=btOutputState.a2dp===2;
  const scanBusy=btOutputState.scanning || btOutputState.scanPreparing;
  const pairedListBusy=!!btInputState.controlPending;
  const modeSelect=getId('btsourcelocal');
  if(modeSelect) modeSelect.disabled=!sourceReady || routeBusy;
  // A2DP state 2 is only an automatic/explicit connection attempt. Manual
  // Scan is allowed to override it; the firmware first sends A2DPDISC and
  // then starts the requested search.
  setBtActionEnabled('btscanbutton',sourceReady && !localOnly && !routeBusy && !scanBusy && !connected && !pairedListBusy);
  const scan=getId('btscanbutton');
  const stop=getId('btstopscanbutton');
  if(scan){
    if(!sourceReady) scan.title='Available in Bluetooth output mode';
    else if(localOnly) scan.title='Bluetooth is disabled in Local only mode';
    else if(routeBusy) scan.title='Waiting for the output mode to become ready';
    else if(pairedListBusy) scan.title='Loading the paired-device list';
    else if(connected) scan.title='Disconnect the current speaker before scanning';
    else scan.title='Search for nearby unpaired Bluetooth audio devices';
  }
  if(scan) scan.classList.toggle('hidden',btOutputState.scanning);
  if(stop) stop.classList.toggle('hidden',!btOutputState.scanning);
  const connectedAddress=String(btOutputState.address||'').toUpperCase();
  document.querySelectorAll('#btsourcerows .bt-source-row').forEach(row=>{
    const isConnected=!!(connected && connectedAddress && row.dataset.address===connectedAddress);
    row.classList.toggle('connected',isConnected);
    const action=row.querySelector('.bt-source-action');
    if(!action) return;
    action.textContent=isConnected?'Disconnect':'Pair';
    action.dataset.command=isConnected?'btdisconnect':'btconnect';
    action.dataset.address=row.dataset.address||'';
    setBtElementEnabled(action,isConnected
      ? sourceReady && !localOnly && !routeBusy && !scanBusy && connected && !btOutputState.pending
      : sourceReady && !localOnly && !routeBusy && !scanBusy && !connected && !connecting && !btOutputState.pending);
  });
  updateBtPairedRows();
}
function upsertBtSourceDevice(item){
  const rows=getId('btsourcerows');
  if(!rows || !item || !item.address) return;
  const address=btAddress(item.address);
  const paired=btPairedDevices.get(address);
  if(paired){
    if(item.rssi!==undefined && item.rssi!==null && Number.isFinite(Number(item.rssi))) paired.rssi=Number(item.rssi);
    if((!paired.name || paired.name==='Unknown device') && item.name) paired.name=item.name;
    const existing=document.querySelector('#btsourcerows .bt-source-row[data-address="'+address+'"]');
    if(existing) existing.remove();
    updateBtPairedRows();
    return;
  }
  let row=Array.from(rows.querySelectorAll('.bt-source-row')).find(entry=>entry.dataset.address===address);
  if(!row){
    const empty=rows.querySelector('.bt-source-empty');
    if(empty) empty.remove();
    row=document.createElement('div');
    row.className='bt-source-row';
    row.setAttribute('role','row');
    row.dataset.address=address;

    const device=document.createElement('div');
    device.className='bt-source-device';
    device.setAttribute('role','cell');
    const name=document.createElement('span');
    name.className='bt-source-name';
    const connected=document.createElement('span');
    connected.className='bt-source-connected';
    connected.textContent='Connected';
    device.append(name,connected);

    const rssi=document.createElement('div');
    rssi.className='bt-source-rssi';
    rssi.setAttribute('role','cell');
    const mac=document.createElement('div');
    mac.className='bt-source-address';
    mac.setAttribute('role','cell');

    const action=document.createElement('div');
    action.className='fb local bt-source-action';
    action.dataset.command='btconnect';
    action.dataset.address=address;
    action.textContent='Pair';
    action.setAttribute('role','button');
    action.setAttribute('tabindex','0');
    row.append(device,rssi,mac,action);
    rows.appendChild(row);
  }
  const name=item.name||row.dataset.name||'Unknown device';
  row.dataset.name=name;
  row.querySelector('.bt-source-name').textContent=name;
  row.querySelector('.bt-source-address').textContent=address;
  if(item.rssi!==undefined && item.rssi!==null && Number.isFinite(Number(item.rssi))){
    row.dataset.rssi=String(Number(item.rssi));
    row.querySelector('.bt-source-rssi').textContent=Number(item.rssi)+' dBm';
  }else if(!row.dataset.rssi){
    row.querySelector('.bt-source-rssi').textContent='—';
  }
  const action=row.querySelector('.bt-source-action');
  action.dataset.label=name;
}
function handleBtOutputState(state){
  btOutputState=Object.assign(btOutputState,state||{});
  if(btOutputState.address && btOutputState.a2dp>=3 && btOutputState.a2dp<=5){
    const address=btAddress(btOutputState.address);
    const previous=btPairedDevices.get(address)||{};
    btPairedDevices.set(address,Object.assign(previous,{address:address,name:btOutputState.name||previous.name||'Unknown device',profile:Number(previous.profile)||64}));
  }
  updateBtRoleStatus();
  updateBtOutputControls();
  updateBtInputControls();
}
function handleBtScanEvent(scan){
  if(!scan) return;
  const rows=getId('btsourcerows');
  const status=getId('btscanstatus');
  if(scan.event==='clear' && rows){
    btPairedDevices.forEach(item=>{ delete item.rssi; });
    rows.replaceChildren();
    const empty=document.createElement('div');
    empty.className='bt-source-empty';
    empty.textContent='No scan results';
    rows.appendChild(empty);
  }
  if(scan.event==='device' && scan.address){
    upsertBtSourceDevice(scan);
  }
  const visibleCount=rows?rows.querySelectorAll('.bt-source-row').length:0;
  if(status){
    status.style.color=scan.event==='error'?'#e36b6b':'';
    if(scan.message) status.textContent=scan.message;
    else if(scan.event==='scanning') status.textContent='Scanning... '+visibleCount+' unpaired device(s) found.';
    else if(scan.event==='done') status.textContent='Scan finished: '+visibleCount+' unpaired device(s) found.';
    else if(scan.event==='idle') status.textContent='Put the speaker into pairing mode, then start a scan.';
    else if(scan.event==='cancelled') status.textContent='Scan stopped.';
    else if(scan.event==='timeout') status.textContent='Scan timed out. You can retry it.';
    else if(scan.event==='paired') status.textContent='Speaker paired successfully.';
    else if(scan.event==='disconnecting') status.textContent='Disconnecting speaker...';
  }
  if(scan.event==='preparing') btOutputState.scanPreparing=true;
  if(scan.event==='scanning' || scan.event==='stopping'){
    btOutputState.scanPreparing=false;
    btOutputState.scanning=true;
  }
  if(['done','idle','cancelled','timeout','error'].includes(scan.event)){
    btOutputState.scanPreparing=false;
    btOutputState.scanning=false;
  }
  updateBtPairedRows();
  updateBtOutputControls();
}
function onMessage(event) {
  if (window.location.pathname === '/dlna.html') { //DLNA mod
    return;
  }
  try{
    const isBluetoothEvent=typeof event.data==='string' && event.data.indexOf('{"bt')===0;
    const data = JSON.parse(isBluetoothEvent?event.data:escapeData(event.data));
    /*ir*/
    if(typeof data.ircode !== 'undefined'){
      getId('protocol').innerText=data.protocol;
      classEach('irrecordvalue', function(el){ if(el.hasClass("active")) el.innerText='0x'+data.ircode.toString(16).toUpperCase(); });
      return;
    }
    if(typeof data.irvals !== 'undefined'){
      classEach('irrecordvalue', function(el,i){ var val = data.irvals[i]; if(val>0) el.innerText='0x'+val.toString(16).toUpperCase(); else el.innerText=""; });
      return;
    }
    /*end ir*/
    if(typeof data.btinput !== 'undefined'){
      handleBtInputState(data.btinput);
      return;
    }
    if(typeof data.btpaired !== 'undefined'){
      handleBtPairedEvent(data.btpaired);
      return;
    }
    if(typeof data.btoutput !== 'undefined'){
      handleBtOutputState(data.btoutput);
      return;
    }
    if(typeof data.btscan !== 'undefined'){
      handleBtScanEvent(data.btscan);
      return;
    }
    if(typeof data.autotimer !== 'undefined'){
      const status=getId('autotimerstatus');
      if(status){
        status.style.color=data.autotimer.saved?'':'#e36b6b';
        status.textContent=data.autotimer.saved?'Saved.':'Could not save timer settings; check the times and retry.';
      }
      return;
    }
    if(typeof data.redirect !== 'undefined'){
      getId("mdnsnamerow").innerHTML=`<h3 style="line-height: 37px;color: #aaa; margin: 0 auto;">redirecting to ${data.redirect}</h3>`;
      setTimeout(function(){ window.location.href=data.redirect; }, 4000);
      return;
    }
    if(typeof data.playermode !== 'undefined') { //Web, SD, BT
      modesd = data.playermode=='modesd';
      const btavailable = data.btavailable === true;
      const modebt = btavailable && data.playermode=='modebt';
      classEach('modeitem', function(el){ el.classList.add('hidden') });
      if(modebt){
        showById(['modesd','volslider'],['modeweb','modebt','sdslider','plsvg','sdsvg','snuffle']);
        classEach('modeweb', function(el){ el.classList.add('hidden'); });
      } else if(modesd){
        showById(['modesd','sdsvg'],['modeweb','plsvg']);
        showById(['sdslider'],['volslider']);
        classEach('modeweb', function(el){ el.classList.add('hidden'); });
      } else {
        showById(['modeweb','plsvg','bitinfo'],['modesd','sdsvg','snuffle']);
        showById(['volslider'],['sdslider']);
        classEach('modeweb', function(el){ el.classList.remove('hidden'); });
      }
      if(btavailable && !modebt) getId('modebt').classList.remove('hidden');
      getId('toggleplaylist').classList.remove('active');
      generatePlaylist(`http://${hostname}/data/playlist.csv`+"?"+new Date().getTime());
      return;
    }
    if(typeof data.sdinit !== 'undefined') {
      if(data.sdinit==1) {
        getId('playernav').classList.add("sd");
        getId('volmbutton').classList.add("hidden");
      }else{
        getId('playernav').classList.remove("sd");
        getId('volmbutton').classList.remove("hidden");
      }
    }
    if(typeof data.sdpos !== 'undefined' && getId("sdpos")){
      if(data.sdtpos==0 && data.sdtend==0){
        getId("sdposvalscurrent").innerHTML="00:00";
        getId("sdposvalsend").innerHTML="00:00";
        getId("sdpos").value = data.sdpos;
        fillSlider(getId("sdpos"));
      }else{
        getId("sdposvalscurrent").innerHTML=secondToTime(data.sdtpos);
        getId("sdposvalsend").innerHTML=secondToTime(data.sdtend);
        getId("sdpos").value = data.sdpos;
        fillSlider(getId("sdpos"));
      }
      return;
    }
    if(typeof data.sdmin !== 'undefined' && getId("sdpos")){
      getId("sdpos").attr('min',data.sdmin); 
      getId("sdpos").attr('max',data.sdmax); 
      return;
    }
    if(typeof data.snuffle!== 'undefined'){
      if(data.snuffle==1){
        getId("snuffle").classList.add("active");
      }else{
        getId("snuffle").classList.remove("active");
      }
      return;
    }
    if(typeof data.payload !== 'undefined'){
      data.payload.forEach(item=> {
        setupElement(item.id, item.value);
      });
    }else{
      if(typeof data.current !== 'undefined') { setCurrentItem(data.current); return; }
      if(typeof data.file !== 'undefined') { generatePlaylist(data.file+"?"+new Date().getTime()); wsSend('submitplaylistdone=1'); return; }
      if(typeof data.act !== 'undefined'){ data.act.forEach(showclass=> { classEach(showclass, function(el) { el.classList.remove("hidden"); }); }); return; }
      Object.keys(data).forEach(key=>{
        setupElement(key, data[key]);
      });
    }
  }catch(e){
    console.log("ws.onMessage error:", event.data);
  }
}
function escapeData(data){
  let m=data.match(/{.+?:\s"(.+?)"}/);
  if(m!==null){
    let m1 = m[1];
    if(m1.indexOf('"') !== -1){
      let mq=m1.replace(/["]/g, '\\\"');
      return data.replace(m1,mq);
    }
  }
  return data;
}
function getId(id,patent=document){
  return patent.getElementById(id);
}
function classEach(classname, callback) {
  document.querySelectorAll(`.${classname}`).forEach((item, index) => callback(item, index));
}
function quoteattr(s) {
  return ('' + s)
    .replace(/&/g, '&amp;')
    .replace(/'/g, '&apos;')
    .replace(/"/g, '&quot;')
    .replace(/</g, '&lt;');
}
HTMLElement.prototype.attr = function(name, value=null){
  if(value!==null){
    return this.setAttribute(name, value);
  }else{
    return this.getAttribute(name);
  }
}
HTMLElement.prototype.hasClass = function(className){
  return this.classList.contains(className);
}
function fillSlider(sl){
  const slaveid = sl.dataset.slaveid;
  const value = (sl.value-sl.min)/(sl.max-sl.min)*100;
  if(slaveid) getId(slaveid).innerText=sl.value;
  sl.style.background = 'linear-gradient(to right, var(--accent-dark) 0%,  var(--accent-dark) ' + value + '%, var(--odd-bg-color) ' + value + '%, var(--odd-bg-color) 100%)';
}
function setupElement(id,value){
  if(id==='encindavail'){
    independentEncodersAvailable = (value === true || value === 1 || value === "1" || value === "true");
    updateIndependentEncodersUi(true);
    return;
  }

  const element = getId(id);
  if(element){
    if(element.classList.contains("checkbox")){
      element.classList.remove("checked");
      const checked = (value === true || value === 1 || value === "1" || value === "true");
      if(checked) element.classList.add("checked");
    }
    if(element.classList.contains("classchange")){
      element.attr("class", "classchange");
      element.classList.add(value);
    }
    if(element.classList.contains("text")){
      element.innerText=value;
    }
    if(element.type==='text' || element.type==='number' || element.type==='password' || element.type==='time'){
      element.value=value;
    }
    if(element.tagName==='SELECT'){
      element.value=String(value);
    }
    if(element.type==='range'){
      element.value=value;
      fillSlider(element);
    }
  }
  if(id==='clockfont' || id==='clockfontmono') {
    updateClockFontMonoUi(false);
  }
  if(id==='encind') {
    updateIndependentEncodersUi(false);
  }
}

function updateClockFontMonoUi(forceSync){
  const fontSel = getId('clockfont');
  const monoToggle = getId('clockfontmono');
  if(!fontSel || !monoToggle) return;

  const isDigi7 = String(fontSel.value) === '0';
  monoToggle.classList.toggle('disabled', !isDigi7);
  monoToggle.attr('aria-disabled', isDigi7 ? 'false' : 'true');

  if(!isDigi7 && monoToggle.classList.contains('checked')){
    monoToggle.classList.remove('checked');
    if(forceSync){
      wsSend('clockfontmono=0');
    }
  }
}

function updateIndependentEncodersUi(forceSync){
  const independentToggle = getId('encind');
  if(!independentToggle) return;

  independentToggle.classList.toggle('disabled', !independentEncodersAvailable);
  independentToggle.attr('aria-disabled', independentEncodersAvailable ? 'false' : 'true');

  if(!independentEncodersAvailable && independentToggle.classList.contains('checked')){
    independentToggle.classList.remove('checked');
    if(forceSync){
      wsSend('encodersindependent=0');
    }
  }
}
/***--- playlist ---***/
function setCurrentItem(item){
  currentItem=item;
  const playlist = getId("playlist");
  if(!playlist) return;
  let topPos = 0, lih = 0;
  playlist.querySelectorAll('li').forEach((item, index)=>{ item.attr('class','play'); if(index+1==currentItem){ item.classList.add("active"); topPos = item.offsetTop; lih = item.offsetHeight; } });
  playlist.scrollTo({ top: (topPos-playlist.offsetHeight/2+lih/2), left: 0, behavior: 'smooth' });
}
function initPLEditor(){
  ple= getId('pleditorcontent');
  if(!ple) return;
  let html='';
  ple.innerHTML="";
  pllines = getId('playlist').querySelectorAll('li');
  pllines.forEach((item,index)=>{
    html+=`<li class="pleitem" id="${'plitem'+index}"><span class="grabbable" draggable="true">${("00"+(index+1)).slice(-3)}</span>
      <span class="pleinput plecheck"><input type="checkbox" class="plcb" /></span>
      <input class="pleinput plename" type="text" value="${quoteattr(item.dataset.name)}" maxlength="140" />
      <input class="pleinput pleurl" type="text" value="${item.dataset.url}" maxlength="140" />
      <span class="pleinput pleplay" data-command="preview">&#9658;</span>
      <input class="pleinput pleovol" type="number" min="-64" max="64" step="1" value="${item.dataset.ovol}" />
      <input class="pleinput pleovol" type="text" value="${quoteattr(item.dataset.genre||'')}" maxlength="64" placeholder="genre" />
      </li>`;
  });
  ple.innerHTML=html;
}
function handlePlaylistData(fileData) {
  const ul = getId('playlist');
  ul.innerHTML='';
  if (!fileData) return;
  const lines = fileData.split('\n');
  let li='', html='';
  for(var i = 0;i < lines.length;i++){
    let line = lines[i].split('\t');
    if(line.length==3 || line.length==4){
      const active=(i+1==currentItem)?' class="active"':'';
      const genre = (line.length==4?line[3].trim():"");
      li=`<li${active} attr-id="${i+1}" class="play" data-name="${line[0].trim()}" data-url="${line[1].trim()}" data-ovol="${line[2].trim()}" data-genre="${genre}"><span class="text">${line[0].trim()}</span><span class="count">${i+1}</span></li>`;
      html += li;
    }
  }
  ul.innerHTML=html;
  setCurrentItem(currentItem);
  if(!modesd) initPLEditor();
  buildGenreIndexFromCSV(fileData);
  annotatePlaylistWithGenres();
  filterPlaylist();
}
let __genreIndexByItem = {};
let __genreList = [];
function buildGenreIndexFromCSV(fileData){
  __genreIndexByItem = {};
  const set = new Set();
  if(!fileData) return;
  const lines = fileData.split('\n');
  let itemIdx = 0;  
  for(let i=0;i<lines.length;i++){
    const raw = lines[i].replace(/\r$/, '');
    if(raw.trim()==='') continue;
    const cols = raw.split('\t');
    const name = (cols[0]||'').trim();
    const isGroup = name.startsWith('***') && name.endsWith('***');
    if(isGroup) continue; 
    itemIdx++; 
    const genre = (cols[3]||'').trim();
    __genreIndexByItem[itemIdx] = genre;
    if(genre) set.add(genre);
  }
  __genreList = Array.from(set).sort((a,b)=>a.localeCompare(b));
}
function filterPlaylist() {
  const customInput = getId('custominput');
  const playlist = getId('playlist');
  if (!playlist || !customInput) return;
  const searchTerm = customInput.value.toLowerCase();
  const items = playlist.querySelectorAll('li');
  items.forEach(item => {
    const name = item.textContent.toLowerCase();
    item.style.display = name.includes(searchTerm) ? '' : 'none';
  });
}
function annotatePlaylistWithGenres(){
  const nodes = document.querySelectorAll('#playlist [attr-id]');
  nodes.forEach((el)=>{
    const idStr = el.getAttribute('attr-id');
    const idx = parseInt(idStr,10);
    if(!isNaN(idx)){
      const g = __genreIndexByItem[idx] || '';
      el.dataset.genre = g;
    }
  });
}
function generatePlaylist(path){
  getId('playlist').innerHTML='<div id="progress"><span id="loader"></span></div>';
  var xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function() {
    if (xhr.readyState == 4) {
      if (xhr.status == 200) {
        handlePlaylistData(xhr.responseText);
      } else {
        handlePlaylistData(null);
      }
    }
  };
  xhr.open("GET", path);
  xhr.send(null);
}
function plAdd(){
  let ple=getId('pleditorcontent');
  let plitem = document.createElement('li');
  let cnt=ple.getElementsByTagName('li');
  plitem.attr('class', 'pleitem');
  plitem.attr('id', 'plitem'+(cnt.length));
  plitem.innerHTML = '<span class="grabbable" draggable="true">'+("00"+(cnt.length+1)).slice(-3)+'</span>\
      <span class="pleinput plecheck"><input type="checkbox" /></span>\
      <input class="pleinput plename" type="text" value="" maxlength="140" />\
      <input class="pleinput pleurl" type="text" value="" maxlength="140" />\
      <span class="pleinput pleplay" data-command="preview">&#9658;</span>\
      <input class="pleinput pleovol" type="number" min="-30" max="30" step="1" value="0" />\
      <input class="pleinput pleovol" type="text" value="" maxlength="64" placeholder="genre" />';
  ple.appendChild(plitem);
  ple.scrollTo({
    top: ple.scrollHeight,
    left: 0,
    behavior: 'smooth'
  });
}
function plRemove(){
  let items=getId('pleditorcontent').getElementsByTagName('li');
  let pass=[];
  for (let i = 0; i <= items.length - 1; i++) {
    if(items[i].getElementsByTagName('span')[1].getElementsByTagName('input')[0].checked) {
      pass.push(items[i]);
    }
  }
  if(pass.length==0) {
    alert('Choose something first');
    return;
  }
  for (var i = 0; i < pass.length; i++)
  {
    pass[i].remove();
  }
  items=getId('pleditorcontent').getElementsByTagName('li');
  for (let i = 0; i <= items.length-1; i++) {
    items[i].getElementsByTagName('span')[0].innerText=("00"+(i+1)).slice(-3);
  }
}
function submitPlaylist(){
  var items=getId("pleditorcontent").getElementsByTagName("li");
  var output="";
  for (var i = 0; i <= items.length - 1; i++) {
    inputs=items[i].getElementsByTagName("input");
    // inputs: 0 checkbox, 1 name, 2 url, 3 ovol, 4 genre
    if(inputs[1].value == "" || inputs[2].value == "") continue;
    let ovol = inputs[3].value;
    if(ovol < -30) ovol = -30;
    if(ovol > 30) ovol = 30;
    let genre = inputs[4].value || '';
    output+=inputs[1].value+"\t"+inputs[2].value+"\t"+ovol+"\t"+genre+"\n";
  }
  let file = new File([output], "tempplaylist.csv",{type:"text/plain;charset=utf-8", lastModified:new Date().getTime()});
  let container = new DataTransfer();
  container.items.add(file);
  let fileuploadinput=getId("file-upload");
  fileuploadinput.files = container.files;
  doPlUpload(fileuploadinput);
  toggleTarget(0, 'pleditorwrap');
}
function doPlUpload(finput) {
  wsSend("submitplaylist=1");
  var formData = new FormData();
  formData.append("plfile", finput.files[0]);
  var xhr = new XMLHttpRequest();
  xhr.open("POST",`http://${hostname}/upload`,true);
  xhr.send(formData);
  finput.value = '';
}
function toggleTarget(el, id){
  const target = getId(id);
  if(id=='pleditorwrap'){
    audiopreview.pause();
    audiopreview.src='';
    getId('previewinfo').innerHTML='';
  }
  if(target){
    if(id=='pleditorwrap' && modesd) {
      getId('sdslider').classList.toggle('hidden');
      getId('volslider').classList.toggle('hidden');
      getId('bitinfo').classList.toggle('hidden');
      getId('snuffle').classList.toggle('hidden');
    }else target.classList.toggle("hidden");
    getId(target.dataset.target).classList.toggle("active");
  }
}
function checkboxClick(cb, command){
  if(cb.classList.contains('disabled')) return;
  cb.classList.toggle("checked");
  wsSend(`${command}=${cb.classList.contains("checked")?1:0}`);
}
function sliderInput(sl, command){
  wsSend(`${command}=${sl.value}`);
  fillSlider(sl);
}
function handleWiFiData(fileData) {
  if (!fileData) return;
  var lines = fileData.split('\n');
  for(var i = 0;i < lines.length;i++){
    let line = lines[i].split('\t');
    if(line.length==2){
      getId("ssid"+i).value=line[0].trim();
      getId("pass"+i).attr('data-pass', line[1].trim());
    }
  }
}
function getWiFi(path){
  var xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function() {
    if (xhr.readyState == 4) {
      if (xhr.status == 200) {
        handleWiFiData(xhr.responseText);
      } else {
        handleWiFiData(null);
      }
    }
  };
  xhr.open("GET", path);
  xhr.send(null);
}
function applyTZ(){
  wsSend("tzh="+getId("tzh").value);
  wsSend("tzm="+getId("tzm").value);
  wsSend("sntp2="+getId("sntp2").value);
  wsSend("sntp1="+getId("sntp1").value);
}
function exportSettings(){
  const rows=[];
  const lastFmKey=getId('lastfmapikey');
  if(lastFmKey&&lastFmKey.value) rows.push(['lastfmapikey',lastFmKey.value]);
  const lastFmEnabled=getId('lastfmenabled');
  if(lastFmEnabled) rows.push(['lastfmenabled',lastFmEnabled.classList.contains('checked')?'1':'0']);
  const processedCmds=new Set();
  document.querySelectorAll('#settingscontent [data-command]').forEach(el=>{
    if(el.classList.contains('local')) return;
    const cmd=el.dataset.command;
    if(processedCmds.has(cmd)) return;
    processedCmds.add(cmd);
    if(el.tagName==='INPUT'||el.tagName==='SELECT'){
      rows.push([cmd,el.value]);
    }else if(el.classList.contains('checkbox')){
      rows.push([cmd,el.classList.contains('checked')?'1':'0']);
    }
  });
  const specialFields=[
    {id:'tzh',cmd:'tzh'},{id:'tzm',cmd:'tzm'},
    {id:'sntp1',cmd:'sntp1'},{id:'sntp2',cmd:'sntp2'},
    {id:'wlat',cmd:'lat'},{id:'wlon',cmd:'lon'},{id:'wkey',cmd:'key'},
    {id:'dateformat',cmd:'dateformat'},{id:'mdns',cmd:'mdnsname'}
  ];
  specialFields.forEach(s=>{
    const el=getId(s.id);
    if(el&&el.value) rows.push([s.cmd,el.value]);
  });
  const csv=rows.map(r=>r[0]+','+r[1]).join('\n');
  const blob=new Blob([csv],{type:'text/csv'});
  const a=document.createElement('a');
  a.href=URL.createObjectURL(blob);
  const stamp = new Date().toISOString().replace(/[:T]/g, "-").slice(0, 19);
  a.download='FusionEdge_settings_'+stamp+'.csv';
  a.click();
  URL.revokeObjectURL(a.href);
}
function importSettings(file){
  const specialCmdToId={
    'tzh':'tzh','tzm':'tzm','sntp1':'sntp1','sntp2':'sntp2',
    'lat':'wlat','lon':'wlon','key':'wkey',
    'dateformat':'dateformat','mdnsname':'mdns',
    'lastfmapikey':'lastfmapikey','lastfmenabled':'lastfmenabled'
  };
  const reader=new FileReader();
  reader.onload=function(e){
    const lines=e.target.result.split('\n').filter(line=>line.trim());
    let index=0;
    const processLine=()=>{
      if(index>=lines.length) return;
      const line=lines[index++];
      const comma=line.indexOf(',');
      if(comma<0){
        processLine();
        return;
      }
      const cmd=line.substring(0,comma).trim();
      const val=line.substring(comma+1).trim();
      if(!cmd){
        processLine();
        return;
      }
      const elByCmd=document.querySelector('[data-command="'+cmd+'"]');
      if(elByCmd){
        if(elByCmd.tagName==='INPUT'||elByCmd.tagName==='SELECT'){
          elByCmd.value=val;
          if(elByCmd.type==='range') fillSlider(elByCmd);
        }else if(elByCmd.classList.contains('checkbox')){
          elByCmd.classList.toggle('checked',val==='1');
        }
      }else if(specialCmdToId[cmd]){
        const el=getId(specialCmdToId[cmd]);
        if(el&&el.classList.contains('checkbox')) el.classList.toggle('checked',val==='1');
        else if(el) el.value=val;
      }
      wsSend(cmd+'='+val);
      setTimeout(processLine,50);
    };
    processLine();
  };
  reader.readAsText(file);
}
function applyDateFormat(){
  const sel = getId("dateformat");
  if(!sel) return;
  wsSend("dateformat=" + parseInt(sel.value, 10));
  wsSend("gettimezone=1");
}
function rebootSystem(info){
  getId("settingscontent").innerHTML=`<h2>${info}</h2>`;
  getId("settingsdone").classList.add("hidden");
  getId("navigation").classList.add("hidden");
  setTimeout(function(){ window.location.href=`http://${hostname}/`; }, 5000);
}
function submitWiFi(){
  var output="";
  var items=document.getElementsByClassName("credential");
  for (var i = 0; i <= items.length - 1; i++) {
    inputs=items[i].getElementsByTagName("input");
    if(inputs[0].value == "") continue;
    let ps=inputs[1].value==""?inputs[1].dataset.pass:inputs[1].value;
    output+=inputs[0].value+"\t"+ps+"\n";
  }
  if(output!=""){ // Well, let's say, quack.
    let file = new File([output], "tempwifi.csv",{type:"text/plain;charset=utf-8", lastModified:new Date().getTime()});
    let container = new DataTransfer();
    container.items.add(file);
    let fileuploadinput=getId("file-upload");
    fileuploadinput.files = container.files;
    var formData = new FormData();
    formData.append("wifile", fileuploadinput.files[0]);
    var xhr = new XMLHttpRequest();
    xhr.open("POST","/upload",true);
    xhr.timeout = 15000;
    xhr.onload = function(){
      if(xhr.status >= 200 && xhr.status < 300){
        getId("settingscontent").innerHTML="<h2>Settings saved. Rebooting...</h2>";
        getId("settingsdone").classList.add("hidden");
        getId("navigation").classList.add("hidden");
        setTimeout(function(){ window.location.href=`http://${hostname}/`; }, 10000);
      }else{
        getId("settingscontent").innerHTML="<h2>Save failed. Please try again.</h2>";
      }
    };
    xhr.onerror = function(){
      getId("settingscontent").innerHTML="<h2>Network error while saving Wi-Fi. Please try again.</h2>";
    };
    xhr.ontimeout = function(){
      getId("settingscontent").innerHTML="<h2>Save timeout. Check AP connection and retry.</h2>";
    };
    xhr.send(formData);
    fileuploadinput.value = '';
  }else{
    getId("settingscontent").innerHTML="<h2>Please enter at least one SSID.</h2>";
  }
}
function playItem(target){
  const item = target.attr('attr-id');
  setCurrentItem(item)
  wsSend(`play=${item}`);
}
function hideSpinner(){
  getId("progress").classList.add("hidden");
  getId("content").classList.remove("hidden");
}
function changeMode(el){
  const cmd = el.dataset.command;
  //setPlaylistMod();
  if(cmd=='bt'){
    wsSend("newmode=2");
    return;
  }
  el.classList.add('hidden');
  if(cmd=='web') getId('modesd').classList.remove('hidden');
  else getId('modeweb').classList.remove('hidden');
  wsSend("newmode="+(cmd=="web"?0:1));
}
function toggleSnuffle(){
  let el = getId('snuffle');
  el.classList.toggle('active');
  wsSend("snuffle="+el.classList.contains('active'));
}
function previewInfo(text, url='', error=false){
  const previewinfo=getId('previewinfo');
  previewinfo.classList.remove('error');
  if(url!='') previewinfo.innerHTML=`${text} <a href="${url}" target="_blank">${url}</a>`;
  else previewinfo.innerHTML=`${text}`;
  if(error) previewinfo.classList.add('error');
}
const PREVIEW_TIMEOUT = 3000;
function playPreview(root) {
  const streamUrl=root.getElementsByClassName('pleurl')[0].value;
  if(root.hasClass('active')){ root.classList.remove('active'); audiopreview.pause(); previewInfo('Stop playback:', streamUrl); return; }
  classEach('pleitem', function(el){ el.classList.remove('active') });
  if(streamUrl=='' || !audiopreview) { previewInfo("No streams available.", '', true); return; }
  previewInfo('Attempting to play:', streamUrl);
  audiopreview.src = streamUrl;
  audiopreview.load();
  let isTimeout = false;
  const timeout = setTimeout(() => { isTimeout = true; previewInfo("Connection timeout", streamUrl, true); root.classList.remove('active'); audiopreview.pause(); audiopreview.src = ''; return; }, PREVIEW_TIMEOUT);
  const onCanPlay = () => { if (!isTimeout) { clearTimeout(timeout); previewInfo('Playback', streamUrl); root.classList.add('active'); audiopreview.play().catch(err => { previewInfo("Playback error:", streamUrl, true); root.classList.remove('active'); return; }); }  };
  const onError = () => { if (!isTimeout) { clearTimeout(timeout); root.classList.remove('active'); previewInfo("Error loading stream:", streamUrl, true); audiopreview.src = ''; return; } };
  audiopreview.addEventListener("canplay", onCanPlay, { once: true });
  audiopreview.addEventListener("error", onError, { once: true });
}
function continueLoading(mode){
  if(loaded) return;
  if(typeof mode === 'undefined' || !mode) mode = 'ap';
  if(mode=="player"){
    const pathname = window.location.pathname;
    if(['/','/index.html'].includes(pathname)){
      document.title = `${yoTitle} - Player`;
      fetch(`player.html?${fwVersion}`).then(response => response.text()).then(player => { 
        getId('content').classList.add('idx');
        getId('content').innerHTML = player; 
        fetch('logo.svg').then(response => response.text()).then(svg => { 
          getId('logo').innerHTML = svg;
          hideSpinner();
          audiopreview = getId('audiopreview');
          generatePlaylist(`http://${hostname}/data/playlist.csv` + "?" + new Date().getTime());
          populateBankSelect();
		  //DLNA mod
			const dlnaBtn = document.getElementById('dlnabtn');
			if (dlnaBtn) {
			  if (typeof dlnaSupported !== 'undefined' && !dlnaSupported) {
				dlnaBtn.classList.add('hidden');
			  } else {
				dlnaBtn.addEventListener('click', openDlna);
				dlnaBtn.classList.remove('hidden');
			  }
			}
        });
        getId("version").innerText=` | v${fwVersion}`;
        document.querySelectorAll('input[type="range"]').forEach(sl => { fillSlider(sl); });
        wsSend('getindex=1');
        //generatePlaylist(`http://${hostname}/data/playlist.csv`+"?"+new Date().getTime());
      });
    }
    if(pathname=='/settings.html'){
      document.title = `${yoTitle} - Settings`;
      fetch(`options.html?${fwVersion}`).then(response => response.text()).then(options => {
        getId('content').innerHTML = options; 
        fetch('logo.svg').then(response => response.text()).then(svg => { 
          getId('logo').innerHTML = svg;
          hideSpinner();
        });
        getId("version").innerText=` | v${fwVersion}`;
        document.querySelectorAll('input[type="range"]').forEach(sl => { fillSlider(sl); });
        wsSend('getsystem=1');
        wsSend('getscreen=1');
        wsSend('gettimezone=1');
        wsSend('getweather=1');
        wsSend('getcontrols=1');
        wsSend('getbtinput=1');
        wsSend('getbtoutput=1');
        getWiFi(`http://${hostname}/data/wifi.csv`+"?"+new Date().getTime());
        wsSend('getactive=1');
        const dateApplyBtn = getId('applydateformatbtn');
        if (dateApplyBtn) {
          dateApplyBtn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            applyDateFormat();
          });
        }
        const clockFontSel = getId('clockfont');
        if (clockFontSel) {
          clockFontSel.addEventListener('input', () => updateClockFontMonoUi(true));
          clockFontSel.addEventListener('change', () => updateClockFontMonoUi(true));
          updateClockFontMonoUi(false);
        }
        classEach("reset", function(el){ el.innerHTML='<svg viewBox="0 0 16 16" class="fill"><path d="M8 3v5a36.973 36.973 0 0 1-2.324-1.166A44.09 44.09 0 0 1 3.417 5.5a52.149 52.149 0 0 1 2.26-1.32A43.18 43.18 0 0 1 8 3z"/><path d="M7 5v1h4.5C12.894 6 14 7.106 14 8.5S12.894 11 11.5 11H1v1h10.5c1.93 0 3.5-1.57 3.5-3.5S13.43 5 11.5 5h-4z"/></svg>'; });
        const settingsImportFile=getId('settings-import-file');
        if(settingsImportFile){
          settingsImportFile.addEventListener('change',function(){
            if(this.files&&this.files[0]) importSettings(this.files[0]);
            this.value='';
          });
        }
      });
    }
    if(pathname=='/update.html'){
      document.title = `${yoTitle} - Update`;
      fetch(`updform.html?${fwVersion}`).then(response => response.text()).then(updform => {
        getId('content').classList.add('upd');
        getId('content').innerHTML = updform; 
        fetch('logo.svg').then(response => response.text()).then(svg => { 
          getId('logo').innerHTML = svg;
          hideSpinner();
        });
        getId("version").innerText=` | v${fwVersion}`;
      });
    }
    if(pathname=='/ir.html'){
      document.title = `${yoTitle} - IR Recorder`;
      fetch(`irrecord.html?${fwVersion}`).then(response => response.text()).then(ircontent => {
        loadCSS(`ir.css?${fwVersion}`);
        getId('content').innerHTML = ircontent; 
        loadJS(`ir.js?${fwVersion}`, () => {
          fetch('logo.svg').then(response => response.text()).then(svg => { 
            getId('logo').innerHTML = svg;
            initControls();
            hideSpinner();
          });
        });
        getId("version").innerText=` | v${fwVersion}`;
      });
    }
    if (window.location.pathname === '/dlna.html') {  //DLNA mod
      document.title = `${yoTitle} - DLNA`;

      fetch(`dlna.html?${fwVersion}`)
        .then(r => r.text())
        .then(html => {
          getId('content').innerHTML = html;
          fetch('logo.svg').then(r => r.text()).then(svg => {
            getId('logo').innerHTML = svg;
            hideSpinner();
          });
          getId("version").innerText = ` | v${fwVersion}`;
        });
    }
  }else{ // AP mode
    fetch(`options.html?${fwVersion}`).then(response => {
      if (!response.ok) throw new Error('options load failed');
      return response.text();
    }).then(options => {
      getId('content').innerHTML = options; 
      fetch('logo.svg').then(response => {
        if (!response.ok) return '';
        return response.text();
      }).then(svg => {
        if (svg) getId('logo').innerHTML = svg;
      }).finally(() => {
        hideSpinner();
      });
      getId("version").innerText=` | v${fwVersion}`;
      getWiFi(`http://${hostname}/data/wifi.csv`+"?"+new Date().getTime());
      // AP fallback: make Wi-Fi section visible even when websocket state sync is delayed.
      const nav = getId('navigation');
      if (nav) nav.classList.remove('hidden');
      classEach('group_wifi', function(el){ el.classList.remove('hidden'); });

      wsSend('getsystem=1');
      wsSend('getscreen=1');
      wsSend('gettimezone=1');
      wsSend('getweather=1');
      wsSend('getcontrols=1');
      wsSend('getbtinput=1');
      wsSend('getbtoutput=1');
      wsSend('getactive=1');
      updateClockFontMonoUi(false);
    }).catch(() => {
      hideSpinner();
      const c = getId('content');
      if (c) c.innerHTML = '<div style="padding:20px;text-align:center;">AP settings page failed to load. Open <a href="/webboard">/webboard</a>.</div>';
    });
  }
  document.body.addEventListener('click', (event) => {
    const source = event.target && event.target.nodeType === 1 ? event.target : event.target && event.target.parentElement;
    let target = source ? source.closest('div, span, li') : null;
    if(!target) return; 
    if(target.classList && target.classList.contains("knob") && target.parentElement) target = target.parentElement;
    if(target.classList && target.classList.contains("snfknob") && target.parentElement) target = target.parentElement;
    if(target.parentElement && target.parentElement.classList && target.parentElement.classList.contains("play")){ playItem(target.parentElement); return; }
    if(target.classList.contains("navitem")) { getId(target.dataset.target).scrollIntoView({ behavior: 'smooth' }); return; }
    if(target.classList.contains("reset")) { wsSend("reset="+target.dataset.name); return; }
    if(target.classList.contains("eqpreset")) {
      const bass = target.dataset.bass;
      const middle = target.dataset.middle;
      const trebble = target.dataset.trebble;
      const bassEl = document.getElementById('bass');
      const middleEl = document.getElementById('middle');
      const trebbleEl = document.getElementById('trebble');
      if(bassEl) { bassEl.value = bass; fillSlider(bassEl); wsSend('bass='+bass); }
      if(middleEl) { middleEl.value = middle; fillSlider(middleEl); wsSend('middle='+middle); }
      if(trebbleEl) { trebbleEl.value = trebble; fillSlider(trebbleEl); wsSend('trebble='+trebble); }
      return;
    }
    if(target.classList.contains("done")) { window.location.href=`http://${hostname}/`; return; }
    let command = target.dataset.command;
    if(!command && source && source.dataset && source.dataset.command){
      command = source.dataset.command;
      target = source;
    }
    if(!command && source){
      const cmdHost = source.closest('[data-command]');
      if(cmdHost){
        command = cmdHost.dataset.command;
        target = cmdHost;
      }
    }
    if (command){
      if (target && (target.tagName === 'INPUT' || target.tagName === 'SELECT' || target.tagName === 'TEXTAREA')) {
        return;
      }
      if(target.classList.contains("local")){
        switch(command){
          case "toggle": toggleTarget(target, target.dataset.target); break;
          case "settings": window.location.href=`http://${hostname}/settings.html`; break;
          case "plimport": break;
          case "plexport": window.open(`http://${hostname}/data/playlist.csv`); break;
          case "pladd": plAdd(); break;
          case "pldel": plRemove(); break;
          case "plselect": {
            const headerCb = target.tagName === 'INPUT' ? target : target.querySelector('input[type="checkbox"]');
            const checked = headerCb ? headerCb.checked : false;
            getId('pleditorcontent').querySelectorAll('li .plecheck input[type="checkbox"]').forEach(cb => { cb.checked = checked; });
            break;
          }
          case "plsubmit": submitPlaylist(); break;
          case "fwupdate": window.location.href=`http://${hostname}/update.html`; break;
          case "webboard": window.location.href=`http://${hostname}/webboard`; break;
          case "themeeditor": window.location.href=`http://${hostname}/theme-editor.html`; break;
          case "setupir": window.location.href=`http://${hostname}/ir.html`; break;
          case "applyweather":
            let key=getId("wkey").value;
            if(key!=""){
              wsSend("lat="+getId("wlat").value);
              wsSend("lon="+getId("wlon").value);
              wsSend("key="+key);
            }
            break;
          case "applylastfm": {
            const keyInput=getId('lastfmapikey');
            const enabledToggle=getId('lastfmenabled');
            const status=getId('lastfmstatus');
            const apiKey=keyInput ? keyInput.value.trim() : '';
            const enabled=enabledToggle && enabledToggle.classList.contains('checked') ? 1 : 0;
            const validKey=/^[0-9a-fA-F]{32}$/.test(apiKey);
            if((enabled && !validKey) || (!enabled && apiKey && !validKey)){
              if(status){
                status.style.color='#e36b6b';
                status.textContent='Enter a valid 32-character API key.';
              }
              break;
            }
            wsSend('lastfmapikey='+apiKey);
            wsSend('lastfmenabled='+enabled);
            if(status){
              status.style.color='';
              status.textContent='Saved.';
            }
            break;
          }
          case "lastfmtoggle": target.classList.toggle('checked'); break;
          case "applytimer": {
            const ids=['autoStartTime','autoStopTime','autoWeekendStartTime','autoWeekendStopTime'];
            const times=ids.map(id=>(getId(id)||{}).value||'');
            const status=getId('autotimerstatus');
            if(!times.every(value=>value===''||/^([01][0-9]|2[0-3]):[0-5][0-9]$/.test(value))){
              if(status){
                status.style.color='#e36b6b';
                status.textContent='Use HH:MM (24-hour time), or leave a field empty.';
              }
              break;
            }
            if(status){
              status.style.color='';
              status.textContent='Saving...';
            }
            wsSend('autotimer='+times.join('|'));
            break;
          }
          case "applybtalias": {
            const aliasInput=getId('btalias');
            const status=getId('btinputstatus');
            const alias=aliasInput ? aliasInput.value.trim() : '';
            const byteLength=new TextEncoder().encode(alias).length;
            if(!alias || byteLength>31 || alias.indexOf(',')!==-1){
              if(status){
                status.style.color='#e36b6b';
                status.textContent='Use 1-31 bytes; commas are not allowed.';
              }
              break;
            }
            if(status){
              status.style.color='';
              status.textContent='Saving Bluetooth alias...';
            }
            wsSend('btalias='+alias);
            break;
          }
          case "btinputrefresh": wsSend("btinputrefresh=1"); break;
          case "btdeviceinfo": {
            const address=target && target.dataset ? target.dataset.address : '';
            openBtDeviceDialog(address);
            break;
          }
          case "btdeviceclose": closeBtDeviceDialog(); break;
          case "btforget": {
            const address=target && target.dataset ? target.dataset.address : '';
            const label=target && target.dataset ? target.dataset.label : '';
            if(!address) break;
            if(window.confirm('Forget this Bluetooth device?\n\n'+(label||'Unknown device')+' — '+address)){
              closeBtDeviceDialog();
              wsSend('btforget='+address);
            }
            break;
          }
          case "btscan": wsSend("btscan=10"); break;
          case "btstopscan": wsSend("btstopscan=1"); break;
          case "btconnect": {
            const address=target && target.dataset ? target.dataset.address : '';
            if(address){
              closeBtDeviceDialog();
              wsSend("btconnect="+address);
            }
            break;
          }
          case "btdisconnect": closeBtDeviceDialog(); wsSend("btdisconnect=1"); break;
          case "applydateformat": applyDateFormat(); break;
          case "applytz": applyTZ(); break;
          case "wifiexport": window.open(`http://${hostname}/data/wifi.csv`+"?"+new Date().getTime()); break;
          case "wifiupload": submitWiFi(); break;
          case "settingsexport": exportSettings(); break;
          case "settingsimport": getId("settings-import-file").click(); break;
          case "reboot": wsSend("reboot=1"); rebootSystem('Rebooting...'); break;
          case "format": wsSend("format=1"); rebootSystem('Format SPIFFS. Rebooting...'); break;
          case "reset":  wsSend("reset=1");  rebootSystem('Reset settings. Rebooting...'); break;
          case "snuffle": toggleSnuffle(); break;
          case "rebootmdns": wsSend(`mdnsname=${getId('mdns').value}`); wsSend("rebootmdns=1"); break;
          default: break;
        }
      }else{
        if(target.classList.contains("checkbox")) checkboxClick(target, command);
        if (target.classList.contains("cmdbutton")) {

          if (command === "toggle" && modesd) {

            // állapot lekérése — játszik-e?
            const isPlaying = target.classList.contains("active");

            if (isPlaying) {
              // épp játszik → STOP → küldjünk 0-t
              wsSend("toggle=0");

            } else {
              // nem játszik → PLAY → küldjük a pozíciót
              let pos = 0;
              const sl = getId("sdpos");
              if (sl && sl.value) pos = sl.value;

              wsSend(`toggle=${pos}`);
            }

          } else {
            wsSend(`${command}=1`);
          }
        }
        if(target.classList.contains("modeitem")) changeMode(target);
        if(target.hasClass("pleplay")) playPreview(target.parentElement);
        if(target.classList.contains("play")){ // A lejátszás indítása.
          const item = target.attr('attr-id');
          setCurrentItem(item)
          wsSend(`${command}=${item}`);
        }
      }
  event.preventDefault();
  event.stopPropagation();
    }
  });
  document.body.addEventListener('input', (event) => {
    const originalTarget = event.target;
    let target = originalTarget;
    let command = target && target.dataset ? target.dataset.command : undefined;
    if (!command && target && target.parentElement && target.parentElement.dataset) {
      command = target.parentElement.dataset.command;
    }
    if (command) {
      if(target && target.type==='range') sliderInput(target, command);  //<-- range
      else wsSend(`${command}=${target ? target.value : ''}`);   //<-- other
      event.preventDefault(); event.stopPropagation();
    }
    if (originalTarget && originalTarget.id === 'bankselect') {
      const selectedOption = originalTarget.selectedOptions[0];
      if (selectedOption && selectedOption.value) {
        const url = selectedOption.dataset.url; 
        if (url) {
          loadPlaylistFromBank(url);
        }
        originalTarget.value = '';
      }
    }
    // New custom bankselect is handled by initBankSelectFilter function
  });
  document.body.addEventListener('change', (event) => {
    const target = event.target;
    if (!target || target.tagName !== 'SELECT') return;
    const command = target.dataset ? target.dataset.command : undefined;
    if (!command) return;
    wsSend(`${command}=${target.value}`);
    event.preventDefault();
    event.stopPropagation();
  });
  document.body.addEventListener('mousewheel', (event) => {
    const target = event.target;
    if(target.type==='range'){
      const command = target.dataset.command;
      target.valueAsNumber += event.deltaY>0?-1:1;
      if (command) {
        sliderInput(target, command);
      }
    }
  });
}
async function loadPlaylistFromBank(url) {
  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error('Failed to load playlist');
    const csvText = await response.text();
    const blob = new Blob([csvText], { type: 'text/csv' });
    const file = new File([blob], 'bankplaylist.csv', { type: 'text/csv' });
    const container = new DataTransfer();
    container.items.add(file);
    const fileInput = getId('file-upload');
    fileInput.files = container.files;
    doPlUpload(fileInput);
    setTimeout(() => {
      wsSend('plsubmit');
    }, 1000); 
  } catch (error) {
    alert('Error loading playlist from bank: ' + error.message);
  }
}
async function populateBankSelect() {
  const bankselectOptions = getId('bankselectoptions');
  const bankselectInput = getId('bankselectinput');
  if (!bankselectOptions || !bankselectInput) return;
  
  const defaultOptions = [
    { value: 'plbank1', text: 'Bank 1 General', url: 'https://raw.githubusercontent.com/mirek76/playlist/refs/heads/main/generalplaylist.csv' },
    { value: 'plbank2', text: 'Bank 2 Jazz', url: 'https://raw.githubusercontent.com/mirek76/playlist/refs/heads/main/jazzplaylist.csv' },
    { value: 'plbank3', text: 'Bank 3 Metal', url: 'https://raw.githubusercontent.com/mirek76/playlist/refs/heads/main/metalplaylist.csv' },
    { value: 'plbank4', text: 'Bank 4 Pop', url: 'https://raw.githubusercontent.com/mirek76/playlist/refs/heads/main/popplaylist.csv' },
    { value: 'plbank5', text: 'Bank 5 Rock', url: 'https://raw.githubusercontent.com/mirek76/playlist/refs/heads/main/rockplaylist.csv' }
  ];

  try {
    const response = await fetch('https://api.github.com/repos/mirek76/playlist/contents/');
    if (!response.ok) throw new Error('GitHub API error');
    const files = await response.json();
    const csvFiles = files.filter(file => file.name.endsWith('.csv') && file.type === 'file');
    if (csvFiles.length === 0) throw new Error('No CSV files found');
    
    bankselectOptions.innerHTML = '<div class="bankselectoption" data-value="">Select a bank...</div>';
    
    csvFiles.forEach((file, index) => {
      const option = document.createElement('div');
      option.className = 'bankselectoption';
      option.setAttribute('data-value', `plbank${index + 1}`);
      const name = file.name.replace('.csv', '').replace('playlist', '').replace(/^\w/, c => c.toUpperCase());
      option.textContent = `Bank ${index + 1} ${name}`;
      option.setAttribute('data-url', file.download_url);
      bankselectOptions.appendChild(option);
    });
  } catch (error) {
    console.log('Error loading bank select from GitHub:', error.message);
    bankselectOptions.innerHTML = '<div class="bankselectoption" data-value="">Select a bank...</div>';
    
    defaultOptions.forEach(opt => {
      const option = document.createElement('div');
      option.className = 'bankselectoption';
      option.setAttribute('data-value', opt.value);
      option.textContent = opt.text;
      option.setAttribute('data-url', opt.url);
      bankselectOptions.appendChild(option);
    });
  }
  
  // Uproszczona inicjalizacja - podstawowe nasłuchiwanie zdarzeń
  bankselectInput.addEventListener('click', () => {
    bankselectOptions.classList.toggle('hidden');
  });
  
  bankselectOptions.addEventListener('click', (e) => {
    if (e.target.classList.contains('bankselectoption')) {
      const value = e.target.getAttribute('data-value');
      const url = e.target.getAttribute('data-url');
      if (value && url) {
        loadPlaylistFromBank(url);
      }
      bankselectOptions.classList.add('hidden');
    }
  });
  
  // Zamykanie dropdown po kliknięciu poza elementem
  document.addEventListener('click', (e) => {
    if (bankselectInput && bankselectOptions && 
        !bankselectInput.contains(e.target) && 
        !bankselectOptions.contains(e.target)) {
      bankselectOptions.classList.add('hidden');
    }
  });
}

/** UPDATE **/
var uploadWithError = false;
function doUpdate(el) {
  let binfile = getId('binfile').files[0];
  if(binfile){
    getId('updateform').attr('class','hidden');
    getId("updateprogress").value = 0;
    getId('updateprogress').hidden=false;
    getId('update_cancel_button').hidden=true;
    var formData = new FormData();
    formData.append("updatetarget", getId('uploadtype1').checked?"firmware":"spiffs");
    formData.append("update", binfile);
    var xhr = new XMLHttpRequest();
    uploadWithError = false;
    xhr.onreadystatechange = function() {
      if (xhr.readyState == XMLHttpRequest.DONE) {
        if(xhr.responseText!="OK"){
          getId("uploadstatus").innerHTML = xhr.responseText;
          uploadWithError=true;
        }
      }
    }
    xhr.upload.addEventListener("progress", progressHandler, false);
    xhr.addEventListener("load", completeHandler, false);
    xhr.addEventListener("error", errorHandler, false);
    xhr.addEventListener("abort", abortHandler, false);
    xhr.open("POST",`http://${hostname}/update`,true);
    xhr.send(formData);
  }else{
    alert('Choose something first');
  }
}
function progressHandler(event) {
  var percent = (event.loaded / event.total) * 100;
  getId("uploadstatus").innerHTML = Math.round(percent) + "%&nbsp;&nbsp;uploaded&nbsp;&nbsp;|&nbsp;&nbsp;please wait...";
  getId("updateprogress").value = Math.round(percent);
  if (percent >= 100) {
    getId("uploadstatus").innerHTML = "Please wait, writing file to filesystem";
  }
}
var tickcount=0;
function rebootingProgress(){
  getId("updateprogress").value = Math.round(tickcount/7);
  tickcount+=14;
  if(tickcount>700){
    location.href=`http://${hostname}/`;
  }else{
    setTimeout(rebootingProgress, 200);
  }
}
function completeHandler(event) {
  if(uploadWithError) return;
  getId("uploadstatus").innerHTML = "Upload Complete, rebooting...";
  rebootingProgress();
}
function errorHandler(event) {
  getId('updateform').attr('class','');
  getId('updateprogress').hidden=true;
  getId("updateprogress").value = 0;
  getId("status").innerHTML = "Upload Failed";
}
function abortHandler(event) {
  getId('updateform').attr('class','');
  getId('updateprogress').hidden=true;
  getId("updateprogress").value = 0;
  getId("status").innerHTML = "inUpload Aborted";
}
/** UPDATE **/
// === CUSTOM CODE START ===
//DLNA functions

// --- DLNA playlist activation via /upload  ---

function openDlna() {
  window.location.href = 'dlna.html';
}

// === CUSTOM CODE END ===
